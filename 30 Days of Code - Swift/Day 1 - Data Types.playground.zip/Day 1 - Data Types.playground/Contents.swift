

//Code by Subiksha Sureender

var i = 4
var d = 4.0
var s = "HackerRank "

// Declaring, reading and saving second integer, double, and String variables.

let ii = readLine()!
let dd = readLine()!
let ss = readLine()!


let sum1 = i + Int(ii)!  //calculating sum of two integers
let sum2 = d + Double(dd)!  //calculating sum of two doubles


print(sum1) // printng sum of integers
print(sum2) // printing sum of doubles
print(s+ss) //printing concatenated strings



